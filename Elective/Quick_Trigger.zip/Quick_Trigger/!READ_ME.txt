Thank you for installing Quick Trigger.

For an optimised experience:

- Turn on sound (Good speakers or headphones recommended).
- Run 'Quick_Trigger' to play.
- Do not move or edit anything inside 'Game Files'
- Keep 'Quick_Trigger' and 'Game Files' in the same directory.
- Run the .py files in CMD rather than IDLE.

Unfortunately, the game occassionally crashes when moving between
missions / cutscenes. If this happens, keep loading it until it works.
It also does not work in CMD on every computer (strangely). Use CMD if you
can.

Enjoy.